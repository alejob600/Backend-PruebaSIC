package com.pruebasic.testsic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestsicApplicationTests {

	@Test
	void contextLoads() {
	}

}
