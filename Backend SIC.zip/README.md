# Backend-PruebaSIC
Back diseñada con Spring y Java 

compilar con Vscode o IntelliJ IDEA

